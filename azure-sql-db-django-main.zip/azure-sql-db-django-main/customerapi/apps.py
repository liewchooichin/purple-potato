from django.apps import AppConfig


class customerapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'customerapi'
